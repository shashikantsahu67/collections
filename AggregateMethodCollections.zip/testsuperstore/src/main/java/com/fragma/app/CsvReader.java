package com.fragma.app;

import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CsvReader {
    public static List<SuperStore> parseCSVFileAsList() throws IOException {
        //create CSVReader object
        String file = "C:\\Users\\LENOVO\\Documents\\Power BI\\super store\\SuperStoreUS_2015.csv";
        CSVReader reader = new CSVReader(new FileReader(file), ',');

        List<SuperStore> stores = new ArrayList<SuperStore>();
        //read all lines at once
        List<String[]> records = reader.readAll();
        Iterator<String[]> iterator = records.iterator();
        //skip header row
        iterator.next();
        while (iterator.hasNext()) {
            String[] record = iterator.next();
            SuperStore superStore = new SuperStore();
            superStore.setRow_ID(Integer.parseInt(record[0]));
            superStore.setProduct_Category(record[8]);
            superStore.setRegion(record[12]);
            superStore.setProfit(Double.parseDouble(record[16]));
            stores.add(superStore);
        }
        reader.close();
        return stores;
    }
}
