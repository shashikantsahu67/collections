package com.fragma.app;

import java.util.*;
public class GroupByProfit {
    public HashMap<String,Double> groupByRegionProduct(List<SuperStore> superStores)
    {
        HashMap<String,Double> stringIntegerHashMap=new HashMap<String, Double>();
        double totalSales=0;
        String productRegion;
        for (SuperStore financial_sample:superStores)
        {
            productRegion=financial_sample.getProduct_Category()+" "+financial_sample.getRegion();
            if (!stringIntegerHashMap.containsKey(productRegion))
            {
                stringIntegerHashMap.put(productRegion,financial_sample.getProfit());
            }
            else
            {
                totalSales=financial_sample.getProfit()+stringIntegerHashMap.get(productRegion);
                stringIntegerHashMap.put(productRegion,totalSales);
            }
        }
        Set<String> setCodes1 = stringIntegerHashMap.keySet();
        Iterator<String> iterators = setCodes1.iterator();

        while (iterators.hasNext()) {
            String code = iterators.next();
            Double country = stringIntegerHashMap.get(code);
            System.out.println(code + " => " + country);
        }
        return stringIntegerHashMap;
    }
    public HashMap<String,Integer> groupByRegionCount(List<SuperStore> superStores)
    {
        HashMap<String,Integer> stringIntegerHashMap=new HashMap<String, Integer>();
        //int count=1;
        String productRegion;
        for (SuperStore financial_sample:superStores)
        {
            productRegion=financial_sample.getProduct_Category()+" "+financial_sample.getRegion();
            if (!stringIntegerHashMap.containsKey(productRegion))
            {
                stringIntegerHashMap.put(productRegion,1);
            }
            else
            {
                stringIntegerHashMap.put(productRegion,stringIntegerHashMap.get(productRegion)+1);
            }
        }
        Set<String> setCodes1 = stringIntegerHashMap.keySet();
        Iterator<String> iterators = setCodes1.iterator();

        while (iterators.hasNext()) {
            String code = iterators.next();
            Integer country = stringIntegerHashMap.get(code);

            System.out.println(code + " => " + country);
        }
        return stringIntegerHashMap;
    }
    public HashMap<String,Double> groupByRegionProfit(HashMap<String,Double> profit ,HashMap<String,Integer> count)
    {
        Set<String> setCodes = profit.keySet();
        Iterator<String> iterator = setCodes.iterator();
        HashMap<String,Double> hashMap=new HashMap<String, Double>();
        while (iterator.hasNext()) {
            String code = iterator.next();
            Integer counts = count.get(code);
            Double profits=profit.get(code);
            Double groups=profits/counts;
            hashMap.put(code,groups);
        }
        Set<String> setCodes1 = hashMap.keySet();
        Iterator<String> iterators = setCodes1.iterator();
        while (iterators.hasNext()) {
            String code = iterators.next();
            Double country = hashMap.get(code);
            System.out.println(code + " => " + country);
        }
        return hashMap;
    }
    public HashMap<String,Double> groupByRegionProductTest(List<SuperStore> superStores)
    {
       HashMap<String,Double> stringIntegerHashMap=new HashMap<String, Double>();
       Iterator<SuperStore> superStoreIterator=superStores.iterator();
       double totalProfit;
       int i=0;
        while (i < superStores.size()) {
            String region=superStores.get(i).getRegion();
            Double profit=superStores.get(i).getProfit();

            if (!stringIntegerHashMap.containsKey(region))
            {
                stringIntegerHashMap.put(region,profit);
            }else{
                totalProfit=profit+stringIntegerHashMap.get(region);
                stringIntegerHashMap.put(region,totalProfit);
            }
            i++;
        }
     /* Iterator<Map.Entry<String,Double>> entryIterator=stringIntegerHashMap.entrySet().iterator();
       while (entryIterator.hasNext())
       {
           String key = entryIterator.next().getKey();
           Double val = stringIntegerHashMap.get(key);
           System.out.println(key+" "+val);
           System.out.println(i);
       }*/
        return stringIntegerHashMap;
    }
    public HashMap<String, Double> groupByRegionProfit1(HashMap<String, Double> profit, HashMap<String, Integer> count) {
        Set<String> setCodes = profit.keySet();
        Iterator<String> iterator = setCodes.iterator();
        HashMap<String, Double> hashMap = new HashMap<String, Double>();
        while (iterator.hasNext()) {
            String code = iterator.next();
            Integer counts = count.get(code);
            Double profits = profit.get(code);
            Double groups = profits / counts;
            hashMap.put(code, groups);
        }
        Set<String> setCodes1 = hashMap.keySet();
        Iterator<String> iterators = setCodes1.iterator();

        while (iterators.hasNext()) {
            String code = iterators.next();
            Double country = hashMap.get(code);

            System.out.println(code + " => " + country);
        }
        return hashMap;
    }

    public HashMap<String, Double> groupByRegion1(List<SuperStore> superStores) {
        HashMap<String, Double> stringIntegerHashMap = new HashMap<String, Double>();
        double totalSales = 0;
        for (SuperStore financial_sample : superStores) {
            if (!stringIntegerHashMap.containsKey(financial_sample.getRegion())) {
                stringIntegerHashMap.put(financial_sample.getRegion(), financial_sample.getProfit());
            } else {
                totalSales = financial_sample.getProfit() + stringIntegerHashMap.get(financial_sample.getRegion());
                stringIntegerHashMap.put(financial_sample.getRegion(), totalSales);
            }
        }
        return stringIntegerHashMap;
    }

    public HashMap<String, Integer> groupByRegionCount1(List<SuperStore> superStores) {
        HashMap<String, Integer> stringIntegerHashMap = new HashMap<String, Integer>();
        int count = 1;
        for (SuperStore financial_sample : superStores) {
            if (!stringIntegerHashMap.containsKey(financial_sample.getRegion())) {
                stringIntegerHashMap.put(financial_sample.getRegion(), 1);
            } else {
                stringIntegerHashMap.put(financial_sample.getRegion(), stringIntegerHashMap.get(financial_sample.getRegion()) + 1);
            }
        }
        return stringIntegerHashMap;
    }
}
