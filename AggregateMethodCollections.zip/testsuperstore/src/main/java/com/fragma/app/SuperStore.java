package com.fragma.app;


public class SuperStore {
    private int Row_ID;
    private String Product_Category;
    private String Region;
    private double Profit;

    public SuperStore(int row_ID, String product_Category, String region, double profit) {
        Row_ID = row_ID;
        Product_Category = product_Category;
        Region = region;
        Profit = profit;
    }

    public SuperStore() {

    }

    @Override
    public String toString() {
        return "SuperStore{" +
                "Row_ID=" + Row_ID +
                ", Product_Category='" + Product_Category + '\'' +
                ", Region='" + Region + '\'' +
                ", Profit=" + Profit +
                '}';
    }


    public int getRow_ID() {
        return Row_ID;
    }

    public void setRow_ID(int row_ID) {
        Row_ID = row_ID;
    }

    public String getProduct_Category() {
        return Product_Category;
    }

    public void setProduct_Category(String product_Category) {
        Product_Category = product_Category;
    }

    public String getRegion() {
        return Region;
    }

    public void setRegion(String region) {
        Region = region;
    }

    public double getProfit() {
        return Profit;
    }

    public void setProfit(double profit) {
        Profit = profit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SuperStore that = (SuperStore) o;
        return Row_ID == that.Row_ID &&
                Double.compare(that.Profit, Profit) == 0 &&
                Product_Category.equals(that.Product_Category) &&
                Region.equals(that.Region);
    }

    @Override
    public int hashCode() {
        return Row_ID*31+5;
    }
}
