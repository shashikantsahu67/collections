package com.fragma.app;

import com.fragma.dao.SuperStoreDAO;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.*;

public class DriverClass {
    public static Connection con = null;
    public static void main(String ar[]) {

        while(true) {
            System.out.println(" Aggregate Operation ...");
            System.out.println("1 . Count ");
            System.out.println("2 . sum ");
            System.out.println("3 . min ");
            System.out.println("4 . max ");
            System.out.println("5 . Average ");
            System.out.println("\n Enter your choice ...");
            int choice = new Scanner(System.in).nextInt();
            try {
            switch (choice) {
                case 1:
                    new GroupByProfit().groupByRegionCount(CsvReader.parseCSVFileAsList());
                    // to count the number of occurence of prduct or region
                    break;
                case 2:
                    // class Delete and method delete(Statement st)
                    break;
                case 3:
                   // class View and method view(Statement st)
                    break;
                case 4:
                   // class Update and method update(Statement st)
                    break;
                case 5:
                    // class Rename and method rename(Statement st)
                    break;
                case 6:
                    System.exit(1);
                    break; // to stop the Application
                default:
                    System.out.println("Invalid choice");
                    break;
            }



        /*  HashMap<String,Double> hashMap1=new DriverClass().groupByRegion(parseCSVFileAsList()) ;
            Iterator<Map.Entry<String,Double>> entryIterator=hashMap1.entrySet().iterator();
            while (entryIterator.hasNext())
            {
                String key =entryIterator.next().getKey();
                Double value=hashMap1.get(key);
                System.out.println(key+" "+value);
            }*/
                //HashMap<String,Integer> hashMap2=new DriverClass().groupByRegionCount(parseCSVFileAsList());

                //setStudentRegistration( new DriverClass().groupByRegionProfit(hashMap1,hashMap2));
           /* HashMap<String, Double> hashMap1 = new GroupByProfit().groupByRegionProduct(parseCSVFileAsList());
            HashMap<String, Integer> hashMap2 = new GroupByProfit().groupByRegionCount(parseCSVFileAsList());
            new SuperStoreDAO().setStudentRegistration(new GroupByProfit().groupByRegionProfit(hashMap1, hashMap2));*/
                new GroupByProfit().groupByRegionProductTest(CsvReader.parseCSVFileAsList());
            } catch (Exception r) {
                System.out.println(r);
            }
        }

    }


   /* public static List readAllData()
    {
        String csvFilename = "C:\\Users\\LENOVO\\Documents\\Power BI\\Financial Sample.csv";
        List content=null;
        try {
            CSVReader csvReader = new CSVReader(new FileReader(csvFilename));

            content = csvReader.readAll();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }
    public static List<Financial_Sample> mapToBean(List list) {
        List<Financial_Sample> financialSampleList = new ArrayList<>();
        Financial_Sample fs = null;
        int line_number = 0;
        String[] row = null;
        List content = readAllData();
        for (Object test : content) {
            if (line_number == 0) {
                line_number++;
                continue;
            }
            line_number++;
            row = (String[]) test;
            try {
                fs = new Financial_Sample(row[0], row[1], row[2], row[3], Integer.parseInt(row[4]), Integer.parseInt(row[5]), Integer.parseInt(row[6]),
                        Integer.parseInt(row[7]), Integer.parseInt(row[8]), Integer.parseInt(row[9]),
                        Integer.parseInt(row[10]), Integer.parseInt(row[11]), row[12], Integer.parseInt(row[13]), row[14], Integer.parseInt(row[15]));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            financialSampleList.add(fs);
        }
        return financialSampleList;
    }
*/
}

