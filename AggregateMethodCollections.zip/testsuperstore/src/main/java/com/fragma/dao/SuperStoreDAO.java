package com.fragma.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class SuperStoreDAO {
    public static Connection con;

    public static void setStudentRegistration(HashMap<String, Double> map) {
        String url = "jdbc:mysql://localhost:3306/world";
        String username = "root";
        String password = "shashi218";
        PreparedStatement preparedStmt = null;
        String sql2 = "insert into SuperStoreGroup(region,profit) values (?,?)";
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            preparedStmt = con.prepareStatement(sql2);
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            con.setAutoCommit(false);
            Set<String> setCodes = map.keySet();
            Iterator<String> iterator = setCodes.iterator();
            while (iterator.hasNext()) {
                String region = iterator.next();
                Double avgprofit = map.get(region);

                preparedStmt.setString(1, region);
                preparedStmt.setDouble(2, avgprofit);
                preparedStmt.addBatch();
            }
            preparedStmt.executeBatch();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("record successfully saved");
        try {
            con.commit();
            preparedStmt.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
